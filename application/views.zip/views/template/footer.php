<div class="clearfix"></div>
        <footer>
            <div class="container-fluid">
                <p class="copyright">&copy; 2017 <a href="https://www.themeineed.com" target="_blank">Theme I Need</a>. All Rights Reserved.</p>
            </div>
        </footer>
    </div>
    <!-- END WRAPPER -->
    <!-- Javascript -->
    
    
    <script src="<?= base_url('') ?>assets/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?= base_url('') ?>assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
    <!-- <script src="<?= base_url('') ?>assets/vendor/jquery.easy-pie-chart/jquery.easypiechart.min.js"></script> -->
    <!-- <script src="<?= base_url('') ?>assets/vendor/chartist/js/chartist.min.js"></script> -->
    <script src="<?= base_url('') ?>assets/scripts/klorofil-common.js"></script>

    <!-- DataTables JavaScript -->
    <script src="<?= base_url('') ?>assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="<?= base_url('') ?>assets/vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="<?= base_url('') ?>assets/vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Bootstrap Datepicker JavaScript -->
    <script src="<?= base_url('assets/datepicker') ?>/js/bootstrap-datepicker.min.js"></script>
</body>

</html>
